let configuration = {

  client_ID : "908046556011-80kbve0btf4nnn1o4vd010a0ag59tfj5.apps.googleusercontent.com",
    firebase_config : {
        apiKey: "AIzaSyAbY4nV71yiRKOo83KAv0c2xm-IV5fmH6k",
        authDomain: "test-pfacs.firebaseapp.com",
        databaseURL: "https://test-pfacs.firebaseio.com",
        projectId: "test-pfacs",
        storageBucket: "test-pfacs.appspot.com",
        messagingSenderId: "908046556011"
    }
}

module.exports = configuration;